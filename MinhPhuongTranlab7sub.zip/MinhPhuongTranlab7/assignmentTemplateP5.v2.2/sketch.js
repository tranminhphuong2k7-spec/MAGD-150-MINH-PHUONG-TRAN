let itemSlots = [];
let itemPrices = []; 
let inventoryLog = [];

let luckySlot, randomPrice, mysterySelection;

function setup() {
  createCanvas(400, 400);
  background(50, 50, 60);
  
  for (let i = 0; i < 5; i++) {
    itemSlots.push(floor(random(10, 99)));
    itemPrices.push(floor(random(1, 5)));
  }

  itemSlots.unshift(1); 
  itemPrices.pop();

  console.log("Available Slots:", itemSlots);
  console.log("Current Prices:", itemPrices);

  inventoryLog = itemSlots.concat(itemPrices);
  console.log("Full Inventory Log:", inventoryLog);

  luckySlot = random(itemSlots);
  randomPrice = random(itemPrices);
  mysterySelection = random(inventoryLog);
  
  noLoop();
}

function draw() {
  fill(0, 255, 100);
  textSize(16);
  textFont('Courier New'); 

  text("Array 1 (Slots): " + itemSlots.join(", "), 20, 60);
  text("Array 2 (Prices): $" + itemPrices.join(", $"), 20, 90);
  
  stroke(0, 255, 100, 50);
  line(20, 120, 380, 120);
  noStroke();

  text("Random 1 (Lucky Slot): " + luckySlot, 20, 160);
  text("Random 2 (Price Point): $" + randomPrice, 20, 190);
  
  fill(255, 200, 0);
  text("Random 1 & 2 (Dispensing): " + mysterySelection, 20, 240);
  
}